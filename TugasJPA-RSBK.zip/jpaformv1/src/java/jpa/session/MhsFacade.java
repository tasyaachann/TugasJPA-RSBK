/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.session;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jpa.entities.Mhs;

/**
 *
 * @author Clawdy
 */
@Stateless
public class MhsFacade extends AbstractFacade<Mhs> {

    @PersistenceContext(unitName = "jpaformv1PU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MhsFacade() {
        super(Mhs.class);
    }
    
}
