/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Clawdy
 */
@Entity
@Table(name = "mhs")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mhs.findAll", query = "SELECT m FROM Mhs m")
    , @NamedQuery(name = "Mhs.findByIdMhs", query = "SELECT m FROM Mhs m WHERE m.idMhs = :idMhs")
    , @NamedQuery(name = "Mhs.findByNamaMhs", query = "SELECT m FROM Mhs m WHERE m.namaMhs = :namaMhs")
    , @NamedQuery(name = "Mhs.findByNim", query = "SELECT m FROM Mhs m WHERE m.nim = :nim")
    , @NamedQuery(name = "Mhs.findByAlamat", query = "SELECT m FROM Mhs m WHERE m.alamat = :alamat")
    , @NamedQuery(name = "Mhs.findByKota", query = "SELECT m FROM Mhs m WHERE m.kota = :kota")
    , @NamedQuery(name = "Mhs.findByEmail", query = "SELECT m FROM Mhs m WHERE m.email = :email")
    , @NamedQuery(name = "Mhs.findByNoTlp", query = "SELECT m FROM Mhs m WHERE m.noTlp = :noTlp")
    , @NamedQuery(name = "Mhs.findByNilai", query = "SELECT m FROM Mhs m WHERE m.nilai = :nilai")
    , @NamedQuery(name = "Mhs.findByKritik", query = "SELECT m FROM Mhs m WHERE m.kritik = :kritik")})
public class Mhs implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_mhs")
    private Integer idMhs;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "nama_mhs")
    private String namaMhs;
    @Basic(optional = false)
    @NotNull
    @Column(name = "nim")
    private int nim;
    @Size(max = 255)
    @Column(name = "alamat")
    private String alamat;
    @Size(max = 30)
    @Column(name = "kota")
    private String kota;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 255)
    @Column(name = "email")
    private String email;
    @Column(name = "no_tlp")
    private Integer noTlp;
    @Size(max = 11)
    @Column(name = "nilai")
    private String nilai;
    @Size(max = 255)
    @Column(name = "kritik")
    private String kritik;

    public Mhs() {
    }

    public Mhs(Integer idMhs) {
        this.idMhs = idMhs;
    }

    public Mhs(Integer idMhs, String namaMhs, int nim) {
        this.idMhs = idMhs;
        this.namaMhs = namaMhs;
        this.nim = nim;
    }

    public Integer getIdMhs() {
        return idMhs;
    }

    public void setIdMhs(Integer idMhs) {
        this.idMhs = idMhs;
    }

    public String getNamaMhs() {
        return namaMhs;
    }

    public void setNamaMhs(String namaMhs) {
        this.namaMhs = namaMhs;
    }

    public int getNim() {
        return nim;
    }

    public void setNim(int nim) {
        this.nim = nim;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getKota() {
        return kota;
    }

    public void setKota(String kota) {
        this.kota = kota;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getNoTlp() {
        return noTlp;
    }

    public void setNoTlp(Integer noTlp) {
        this.noTlp = noTlp;
    }

    public String getNilai() {
        return nilai;
    }

    public void setNilai(String nilai) {
        this.nilai = nilai;
    }

    public String getKritik() {
        return kritik;
    }

    public void setKritik(String kritik) {
        this.kritik = kritik;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idMhs != null ? idMhs.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mhs)) {
            return false;
        }
        Mhs other = (Mhs) object;
        if ((this.idMhs == null && other.idMhs != null) || (this.idMhs != null && !this.idMhs.equals(other.idMhs))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpa.entitles.Mhs[ idMhs=" + idMhs + " ]";
    }
    
}
